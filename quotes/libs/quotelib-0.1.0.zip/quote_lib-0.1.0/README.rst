Quote Library
+++++++++++++

The purpose this library is for pass to test-technique for role as python developer in Geru company. This library is a wrapper of the api rest
https://1c22eh3aj8.execute-api.us-east-1.amazonaws.com/challenge/quotes


dependency
==========

python 3